import os
import shutil
import subprocess
import sys


class EasyVMWindows:

    def __init__(
        self,
        iso_path="windows.iso",
        disk_size="128G",
        ram="12G",
        cores=4,
        accel="whpx",
        base_dir=None,
    ):
        self.base_dir = base_dir or os.getcwd()
        self.qemu_bin = r"C:\Program Files\qemu\qemu-system-x86_64.exe"

        self.iso_path = os.path.join(self.base_dir, iso_path)
        self.disk_path = os.path.join(self.base_dir, "win_hdd.qcow2")

        self.disk_size = disk_size
        self.ram = ram
        self.cores = cores
        self.accel = accel

    def check_environment(self):
        print("[+] Sprawdzanie środowiska QEMU...")
        if not os.path.exists(self.qemu_bin):
            qemu = shutil.which("qemu-system-x86_64")
            if qemu:
                self.qemu_bin = qemu
            else:
                raise RuntimeError(
                    "Nie znaleziono QEMU! Upewnij się, że jest zainstalowane w C:\\Program Files\\qemu."
                )

        if not os.path.exists(self.iso_path):
            print(f"[!] OSTRZEŻENIE: Brak pliku ISO w ścieżce: {self.iso_path}")

    def get_qemu_img_bin(self):
        qemu_dir = os.path.dirname(self.qemu_bin)
        qemu_img = os.path.join(qemu_dir, "qemu-img.exe")
        if not os.path.exists(qemu_img):
            qemu_img = shutil.which("qemu-img")
        return qemu_img

    def create_disk_if_missing(self):
        if not os.path.exists(self.disk_path):
            print(f"[+] Tworzenie wirtualnego dysku ({self.disk_size})...")
            qemu_img = self.get_qemu_img_bin()
            subprocess.run(
                [qemu_img, "create", "-f", "qcow2", self.disk_path, self.disk_size],
                check=True,
            )
            print("[+] Dysk utworzony.")

    def build_qemu_cmd(self, accel_override=None):
        accel_to_use = accel_override or self.accel

        if self.ram.upper().endswith("G"):
            ram_mb = int(self.ram[:-1]) * 1024
        elif self.ram.upper().endswith("M"):
            ram_mb = int(self.ram[:-1])
        else:
            ram_mb = int(self.ram)

        cmd = [
            self.qemu_bin,
            "-accel",
            accel_to_use,
            "-m",
            f"{ram_mb}M",
            "-smp",
            f"{self.cores}",
            "-cpu",
            "qemu64",
            "-machine",
            "pc",
            "-rtc",
            "base=localtime",
            "-vga",
            "std",
            "-usb",
            "-device",
            "usb-tablet",
            "-drive",
            f"file={self.disk_path},format=qcow2",
        ]

        if os.path.exists(self.iso_path):
            cmd.extend(["-cdrom", self.iso_path, "-boot", "d"])

        return cmd

    def run_process(self, accel_mode):
        cmd = self.build_qemu_cmd(accel_override=accel_mode)
        print(f"[+] Próba uruchomienia z akceleracją: {accel_mode}...")
        
        # Przechwytywanie komunikatów błędów z QEMU
        proc = subprocess.Popen(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
        )
        _, stderr = proc.communicate()
        return proc.returncode, stderr

    def start(self):
        try:
            self.check_environment()
            self.create_disk_if_missing()

            code, stderr = self.run_process(self.accel)

            if code != 0:
                print(f"\n[!] Błąd QEMU ({self.accel}):\n{stderr}")
                print("[+] Próba awaryjnego uruchomienia bez akceleracji WHPX (tryb TCG)...")
                
                code_fallback, stderr_fallback = self.run_process("tcg")
                if code_fallback != 0:
                    print(f"\n[!] Błąd QEMU (tcg):\n{stderr_fallback}")

            print("[+] Proces zakończony.")

        except Exception as e:
            print(f"\n[!] Błąd skryptu: {e}")
        
        input("\nNaciśnij Enter, aby zamknąć...")


if __name__ == "__main__":
    vm = EasyVMWindows(
        iso_path="windows.iso",
        disk_size="128G",
        ram="12G",
        cores=4,
        accel="whpx",
    )
    vm.start()